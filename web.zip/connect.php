<?php


$Name = $_POST['Name'];
$email = $_POST['email'];
$Phone = $_POST['Phone.no'];





?>